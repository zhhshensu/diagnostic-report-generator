---
name: diagnostic-report
description: Generate professional, self-contained diagnostic report HTML pages with interactive charts, metrics tables, health status visualization, and optimization recommendations. Use when the user asks for diagnostic reports, health checks, system monitoring reports, performance analysis, fault diagnosis, status reports, or any data-driven inspection report generation.
license: MIT
metadata:
  version: "1.0"
  author: Cocoon AI (hello@cocoon-ai.com)
---

# Diagnostic Report HTML Generator

Generate standardized, production-ready diagnostic report pages as self-contained HTML files with interactive charts, structured data tables, and professional UI styling.

## Output Constraints (Global, Mandatory)

1. Output **only the complete single-file self-contained HTML**. No explanations, no markdown wrapping, no extra text, no comments outside the HTML.
2. All styles, icons, and chart scripts must be loaded via CDN. Zero local dependencies, zero cross-origin restrictions. The file must work when opened directly in a browser by double-clicking.
3. Model-agnostic — compatible with all LLMs. Output must render correctly in any browser, internal network environments, or frontend platforms.
4. Output supports: live preview, download/save, print-to-PDF, embedding in internal platforms.

## Technology Stack

- **Styling:** Tailwind CSS (CDN) for enterprise-grade clean business UI
- **Charts:** Chart.js (CDN), automatically select appropriate chart types:
  - Bar chart for comparison / category data
  - Line chart for trend / time-series data
  - Pie / Doughnut chart for proportions
  - Radar chart for multi-dimensional comparison
- **Layout:** Responsive design for PC, tablet, and mobile
- **Color Scheme:** Professional risk-control palette:
  - Green (`#22c55e`) — Normal / Healthy
  - Yellow (`#eab308`) — Warning / Degraded
  - Red (`#ef4444`) — Critical / Abnormal

## Page Components (ALL Required)

### 1. Report Header Area
- Report title (large, bold)
- Unique report identifier / serial number
- Generation timestamp
- Diagnostic subject / target name
- Notes or remarks (optional context)

### 2. Metrics Data Table
Columns: Metric name, monitored value, threshold, health status, anomaly description

| 指标名称 | 监测值 | 阈值 | 健康状态 | 异常说明 |
|---------|--------|------|---------|---------|

Status badges:
```html
<span class="status-normal">正常</span>   <!-- green -->
<span class="status-warning">警告</span>  <!-- yellow -->
<span class="status-critical">异常</span> <!-- red -->
```

### 3. Data Visualization Area
At least **two different chart types** combined for data comparison and trend analysis:
- Primary chart (bar/column) for metric comparison
- Secondary chart (line/doughnut/radar) for trends or distribution
- Charts should use the risk color palette consistently

### 4. Health Status Labels
- Unified visual treatment: green circle for normal, yellow triangle for warning, red diamond for critical
- Clear visual hierarchy at a glance

### 5. Comprehensive Diagnosis Summary
- Overall score (numerical)
- Risk level (低风险 / 中风险 / 高风险 / 严重)
- Core issues summary (bullet points)
- Key findings highlighted

### 6. Optimization Suggestions
- Targeted remediation plans
- Operational / maintenance recommendations
- Business optimization advice
- Priority indicators (P0/P1/P2 or similar)

## UI & Experience Requirements

- **Card-based layered layout** with proper whitespace, divider lines, zone separation, and subtle shadows for clear hierarchy
- **Sans-serif font stack** (`-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans SC', sans-serif`) for cross-platform Chinese/English/number/symbol compatibility
- **Clean, maintainable code** suitable for frontend platform re-embedding and style customization

## Template

Copy and customize the template at `assets/template.html`. Key customization points:

1. Update report title, ID, timestamp, and subject
2. Populate the metrics data table rows
3. Configure Chart.js chart data (labels, values, colors, chart type)
4. Fill the diagnosis summary section (score, risk level, findings)
5. Add optimization suggestions with priority levels
6. Update footer metadata

## Output

Always produce a single self-contained `.html` file with:
- Tailwind CSS loaded via CDN (`cdn.tailwindcss.com`)
- Chart.js loaded via CDN (`cdn.jsdelivr.net/npm/chart.js`)
- Inline `<script>` blocks for Chart.js initialization
- Embedded `<style>` for any custom CSS overrides

The file must render correctly when opened directly in any modern browser with no network dependencies beyond CDN availability.

## MCP Tool Definition

```json
{
  "name": "diagnostic-report-generator",
  "description": "Generate a standalone HTML diagnostic report with interactive charts, metrics tables, health status visualization, and optimization recommendations based on natural language requirements or structured diagnostic data.",
  "input": "User natural language requirements / custom diagnostic data",
  "output": "Complete standalone HTML document"
}
```
